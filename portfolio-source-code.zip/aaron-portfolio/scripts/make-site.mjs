// Builds the whole website into ONE index.html (all code, styles and photos
// inlined) plus the notebook PDF, in the site/ folder. Those files are all
// GitHub Pages needs, and they can be uploaded without any folders.
import { readFileSync, writeFileSync, mkdirSync, copyFileSync, readdirSync, rmSync } from 'node:fs'
import { join } from 'node:path'

const dist = 'dist-artifact'
let html = readFileSync(join(dist, 'index.html'), 'utf8')

html = html.replace(/<script type="module" crossorigin src="\.\/(assets\/[^"]+\.js)"><\/script>/, (_, file) => {
  const js = readFileSync(join(dist, file), 'utf8').replace(/<\/script/gi, '<\\/script')
  return `<script type="module">${js}</script>`
})
html = html.replace(/<link rel="stylesheet" crossorigin href="\.\/(assets\/[^"]+\.css)">/, (_, file) => {
  return `<style>${readFileSync(join(dist, file), 'utf8')}</style>`
})
if (/src="\.\/assets\/|href="\.\/assets\//.test(html)) throw new Error('Something was not inlined')

rmSync('site', { recursive: true, force: true })
mkdirSync('site', { recursive: true })
writeFileSync(join('site', 'index.html'), html)
for (const f of readdirSync('public')) copyFileSync(join('public', f), join('site', f))
console.log(`site/index.html  ${(html.length / 1024).toFixed(0)} KB  + ${readdirSync('public').join(', ')}`)
