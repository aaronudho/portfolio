# Aaron Udho: portfolio

Video-game themed engineering portfolio built with **React + Vite** (JavaScript, JSX, HTML, CSS).
Every word, number and photo on the site comes from **`src/data.js`**, so updating the site means editing that one file.

---

## Updating the live site (GitHub Pages)

The live site is just two files at the top of the GitHub repo: `index.html` (the whole site in one file) and `elephant-trunk-reacher-notebook.pdf`. No folders needed.

1. Edit `src/data.js` (or ask Claude to).
2. Run `npm run build:site`. This makes the `site/` folder with the new `index.html` and the PDF.
3. On GitHub: **Add file > Upload files**, drag in the new `index.html`, commit. The site updates in 1 to 2 minutes.

One-time setup (already done if the site is live): repo **Settings > Pages > Build and deployment > Source: Deploy from a branch**, Branch **main**, folder **/ (root)**, Save.

---

## Editing content

Open `src/data.js`:

- **Change text or numbers:** edit the strings.
- **Add your GitHub link:** fill in `github` and `githubLabel` in `player`.
- **Add a project:** copy one object in `projects`, give it a new `id`, drop photos in `src/assets/`, import them at the top of the file, and fill in the fields. The project filters, level numbers, "Explored" counter and project page all update on their own.
- **Link a PDF or code:** put the file in `public/` and add `links: [{ label: 'Read it', href: './your-file.pdf' }]` to the project.
- **Mark a certification as earned:** set `unlocked: true` in `achievements`.

## Run it on your computer (optional)

Needs Node.js 20.19+ or 22+.
```bash
npm install
npm run dev        # opens http://localhost:5173
npm run build:site # the finished site goes in site/ (index.html + PDF)
```

## What's inside

- `src/data.js`: all content
- `src/components/Projects.jsx`: the "level select" project grid and filters
- `src/components/ProjectView.jsx`: the project page (photo viewer, objectives, patch notes)
- `src/components/StandSim.jsx`: playable model of the herringbone phone stand
- `src/gears.js`: gear geometry (all gears share one module, so they mesh)
- `src/motion.jsx`: animation clock, reduced-motion support, and the Konami-code "overdrive"
- `src/route.js`: gives every project its own link and makes the Back button close it
- `scripts/make-site.mjs`: packs the whole site into one `index.html` for GitHub Pages
- `public/`: files served as-is (the trunk reacher notebook PDF)
